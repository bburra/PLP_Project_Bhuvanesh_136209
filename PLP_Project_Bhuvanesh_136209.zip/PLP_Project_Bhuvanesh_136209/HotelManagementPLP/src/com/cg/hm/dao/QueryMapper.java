package com.cg.hm.dao;

public interface QueryMapper {
	
	public static String viewAllHotels="SELECT hotels FROM Hotels hotels";
	public static String getRoomByHotelId="SELECT r from RoomDetails r where r.hotelId=:p";
	public static String viewAllRooms="SELECT r from RoomDetails r";
	public static String deleteRoom="DELETE FROM RoomDetails h WHERE h.roomId =:p";
	public static String deleteHotel="DELETE FROM Hotels h WHERE h.hotelId =:p";
	public static String viewBookingDetailsFromDate="SELECT bkd FROM BookingDetails bkd WHERE bkd.bookedFrom <=TO_DATE(:dateS,'yyyy-mm-dd') and bkd.bookedTo>=TO_DATE(:dateS,'yyyy-mm-dd')";
	public static String viewBookingSpecificHotel="SELECT bdetails FROM BookingDetails bdetails WHERE bdetails.hotelId=:hotelId";
	public static String viewGuestListSpecificHotels="SELECT guestList.userId FROM BookingDetails guestList WHERE hotelId =:hotelId";
	public static String  viewGuestListSpecificHotels2="SELECT gList FROM UserDetails gList WHERE userId=:uId";
}
