package com.cg.hm.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hm.dto.BookingDetails;
import com.cg.hm.dto.Hotels;
import com.cg.hm.dto.RoomDetails;
import com.cg.hm.dto.UserDetails;

@Repository
@Transactional
public class HotelDaoImpl implements IHotelDao {
	@PersistenceContext
	private EntityManager entityManager;
	
	private static Logger logger = Logger.getLogger(com.cg.hm.dao.HotelDaoImpl.class);

	@Override
	public void addHotel(Hotels hotelDetails) {
		entityManager.persist(hotelDetails);
		logger.info("HotelDetails inserted successfully with Id-->"+hotelDetails.getHotelId());
	}

	@Override
	public void addRoom(RoomDetails roomDetails) {
		entityManager.persist(roomDetails);
		logger.info("RoomDetails inserted successfully with Id-->"+roomDetails.getRoomId());
	}

	@Override
	public List<Hotels> viewAllHotels() {
		TypedQuery<Hotels> query = entityManager
				.createQuery(QueryMapper.viewAllHotels, Hotels.class);
		List<Hotels> hotels=query.getResultList();
		logger.info("Hotel list is retrieved successfully");
		return hotels;
				
	}

	@Override
	public RoomDetails getRoomById(int roomId) {
		RoomDetails room = entityManager.find(RoomDetails.class, roomId);
		logger.info("Room Details retrieved successfully for RoomID->>>>>"+roomId);
		return room;
	}

	@Override
	public Hotels getHotelById(int hotelId) {
		Hotels hotel = entityManager.find(Hotels.class, hotelId);
		logger.info("Hotel Details retrieved successfully for HotelID->>>>>"+hotelId);
		return hotel;
	}

	@Override
	public List<RoomDetails> getRoomByHotelId(int hotelId) {

		TypedQuery<RoomDetails> querry = entityManager.createQuery(QueryMapper.getRoomByHotelId,
				RoomDetails.class);
		querry.setParameter("p", hotelId);
		List<RoomDetails> rooms=querry.getResultList();
		logger.info("Room List retrieved successfully for HotelID->>>>>"+hotelId);
		return rooms;
	}

	@Override
	public List<RoomDetails> viewAllRooms() {

		TypedQuery<RoomDetails> querry = entityManager.createQuery(QueryMapper.viewAllRooms,
				RoomDetails.class);
		List<RoomDetails> rooms=querry.getResultList();
		logger.info("Room List retrieved successfully ");
		return rooms;
	}

	@Override
	public void deleteRoom(int roomID) {
		Query query = entityManager
				.createQuery(QueryMapper.deleteRoom);
		query.setParameter("p", roomID).executeUpdate();
		logger.info("Room Deleted successfully with ID ->>>>"+roomID);
	}

	@Override
	public void deleteHotel(int hId) {
		Query query = entityManager
				.createQuery(QueryMapper.deleteHotel);
		query.setParameter("p", hId).executeUpdate();
		logger.info("Hotel Deleted successfully with ID ->>>>"+hId);
	}

	@Override
	public void updateHotel(Hotels hotelDetails) {
		entityManager.merge(hotelDetails);
		logger.info("Hotel details updated successfully for HotelID->>>"+hotelDetails.getHotelId());
	}

	@Override
	public void updateRoom(RoomDetails roomDetails) {
		entityManager.merge(roomDetails);
		logger.info("Room details updated successfully for RoomID->>>"+roomDetails.getRoomId());
	}

	@Override
	public List<BookingDetails> viewBookingDetailsFromDate(Date date2) {
		String date;
		date=date2.toString();
		List<BookingDetails> bookingDetails = new ArrayList<BookingDetails>();

		TypedQuery<BookingDetails> quer = entityManager.createQuery(QueryMapper.viewBookingDetailsFromDate,
				BookingDetails.class);
		quer.setParameter("dateS", date);
		bookingDetails = quer.getResultList();
		logger.info("Booking Details retrieved successfully for Date->>>>>"+date2);
		return bookingDetails;
	}

	@Override
	public List<BookingDetails> viewBookingSpecificHotel(int hotelId) {
		TypedQuery<BookingDetails> query = entityManager.createQuery(
				QueryMapper.viewBookingSpecificHotel, BookingDetails.class);
		query.setParameter("hotelId", hotelId);
		List<BookingDetails> b = query.getResultList();
		logger.info("Booking Details retrieved successfully for HotelID->>>>>"+hotelId);
		return b;
	}

	@Override
	public List<UserDetails> viewGuestListSpecificHotels(int hotelId) {

		TypedQuery<Integer> query = entityManager.createQuery(QueryMapper.viewGuestListSpecificHotels,
				Integer.class);
		query.setParameter("hotelId", hotelId);
		List<Integer> uIDList = query.getResultList();
		logger.info("USER List Details retrieved successfully for HotelID->>>>>"+hotelId);
		
		if (!uIDList.isEmpty()) {
			List<UserDetails> list = new ArrayList<>();
			for (int uId : uIDList) {

				TypedQuery<UserDetails> querry = entityManager.createQuery(QueryMapper.viewGuestListSpecificHotels2,
						UserDetails.class);
				querry.setParameter("uId",uId);
				UserDetails user = querry.getSingleResult();
				logger.info("USER Details retrieved successfully for UserID->>>>>"+uId);
				list.add(user);
			}
			return list;
		} else {
			logger.info("No Users for hotel with hotelID->>>>"+hotelId);
			return null;
		}
	}
}
