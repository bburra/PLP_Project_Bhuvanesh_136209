package com.cg.hm.controller;

public interface Constant {
	public static String message = "message";
	public static String message2 = "message2";

	public static String iIP = "Invalid Id or Password!!!";
	public static String hAS = "Hotel Added Successfully!!!";
	public static String rAS = "Room Added Successfully!!!";
	public static String nRA = "No Room Available in This Hotel";
	public static String rDS = "Room Deleted Successfully!!!";
	public static String hDS = "Hotel Deleted Successfully!!!";
	public static String hMS = "Hotel Modified Successfully!!!";
	public static String rMS = "Room Modified Successfully!!!";
	public static String nRB = "No Room Booked in This Hotel";

	public static String[] dropDownList = {"Select","Standard non A/C room",
			"Standard A/C room", "Executive A/C room", "Deluxe A/C room" };
}
