package com.cg.hm.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="hotel")
public class Hotels implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="hotel_id")
	private Integer hotelId;

	//@Size(min=8,max=16,message="Password Length can only be between 8-16")
	@Pattern(regexp="[A-Za-z ]{1,}",message="City Should not have digits")
	@Column(name="city")
	private String city;

	@Pattern(regexp="[A-Za-z ]{1,}",message="Hotel Name Should not have digits")
	@Column(name="hotel_name")
	private String hotelName;

	@NotEmpty
	@Column(name="address")
	private String address;

	@Pattern(regexp="[A-Za-z ]{1,}",message="Enter valid Pattern ex:AC")
	@Column(name="description")
	private String description;

//	@Pattern(regexp="[1-9]{1}[0-9]{1,}",message="It should be a number")
	@Min(1000)
	@Column(name="avg_rate_per_night")
	private Integer  avgRatePerNight;

	@Pattern(regexp="[1-9]{1}[0-9]{9}",message="Phone no. must be 10 digits")
	@Column(name="phone_no1")
	private String phone1;

	@Pattern(regexp="[1-9]{1}[0-9]{9}",message="Phone no. must be 10 digits")
	@Column(name="phone_no2")
	private String phone2;

//	@Pattern(regexp="[1-5]{1}",message="Enter in the range of 1-5")
	@Min(1)
	@Max(5)
	@Column(name="rating")
	private Integer rating;


	@Pattern(regexp="[1-9]{1}[0-9]{4}",message="It Should have Five digits only")
	@Column(name="fax")
	private String fax;

	@Pattern(regexp="[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,3}",message="Enter valid Email Ex:abc@gmail.com")
	@Column(name="email")
	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}



	@Override
	public String toString() {
		return "Hotels [hotelId=" + hotelId + ", city=" + city + ", hotelName="
				+ hotelName + ", address=" + address + ", description="
				+ description + ", avgRatePerNight=" + avgRatePerNight
				+ ", phone1=" + phone1 + ", phone2=" + phone2 + ", rating="
				+ rating + ", fax=" + fax + ", email=" + email + "]";
	}



	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getAvgRatePerNight() {
		return avgRatePerNight;
	}
	public void setAvgRatePerNight(Integer avgRatePerNight) {
		this.avgRatePerNight = avgRatePerNight;
	}
	public String getPhone1() {
		return phone1;
	}
	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}
	public String getPhone2() {
		return phone2;
	}
	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}
	public Integer getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}

}

